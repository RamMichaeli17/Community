classDiagram
direction BT
class APIException {
  + APIException() 
}
class ApiController {
  + ApiController(ApiService) 
  + saveRandomCompany() ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + getUserByGender(String) ResponseEntity~UserEntity~
  + saveUserByGender(String) ResponseEntity~EntityModel~UserEntity~~
   ResponseEntity~CellPhoneCompanyEntity~ company
}
class ApiService {
  + ApiService(ObjectMapper, UserRepo, UserEntityAssembler, CellPhoneCompanyRepo, CellPhoneCompanyAssembler, RestTemplateBuilder) 
  + saveCompany(CellPhoneCompanyEntity) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + generateRandomPhoneNumbers() Set~String~
  + getUserByGender(String) CompletableFuture~UserEntity~
  + saveUser(UserEntity) ResponseEntity~EntityModel~UserEntity~~
  + generateRandomAvatarEntity(String) AvatarEntity
   CompletableFuture~CellPhoneCompanyEntity~ randomCompany
}
class AvatarEntity {
  + AvatarEntity() 
  + AvatarEntity(Integer, Integer, HairColor, Integer) 
  - Integer eyebrows
  - Integer eyes
  - Integer mouth
  - String resultUrl
  - String seed
  - HairColor hairColor
  + equals(Object) boolean
  + toString() String
  + hashCode() int
  # canEqual(Object) boolean
  + createResultUrl() String
   Integer eyes
   String resultUrl
   Integer eyebrows
   HairColor hairColor
   Integer mouth
   String seed
}
class CellPhoneCompanyAssembler {
  + CellPhoneCompanyAssembler() 
  + toModel(CellPhoneCompanyEntity) EntityModel~CellPhoneCompanyEntity~
  + toCollectionModel(Iterable~CellPhoneCompanyEntity~) CollectionModel~EntityModel~CellPhoneCompanyEntity~~
}
class CellPhoneCompanyController {
  + CellPhoneCompanyController(CellPhoneCompanyService) 
  + getCellPhoneCompaniesByCountryAndOptionalNameContains(String, String) ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~
  + deleteCompanyById(Long) ResponseEntity~?~
  + getCellPhoneCompaniesByUserId(Long) ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~
  + getCellPhoneCompanyDtoInfo(Long) ResponseEntity~EntityModel~CellPhoneCompanyDTO~~
  + updateCellPhoneCompany(CellPhoneCompanyEntity) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + deleteCompanyByName(String) ResponseEntity~?~
  + getCompanyBySpecificParameter(String, String) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + createCompany(CellPhoneCompanyEntity) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
   ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyDTO~~~ allCellPhoneCompaniesDtoInfo
   ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~ allCompanies
}
class CellPhoneCompanyDTO {
  + CellPhoneCompanyDTO(CellPhoneCompanyEntity) 
  - CellPhoneCompanyEntity cellPhoneCompany
  + equals(Object) boolean
  + hashCode() int
  + toString() String
   CellPhoneCompanyEntity cellPhoneCompany
   String companyName
   String summary
}
class CellPhoneCompanyDTOAssembler {
  + CellPhoneCompanyDTOAssembler() 
  + toModel(CellPhoneCompanyDTO) EntityModel~CellPhoneCompanyDTO~
  + toCollectionModel(Iterable~CellPhoneCompanyDTO~) CollectionModel~EntityModel~CellPhoneCompanyDTO~~
}
class CellPhoneCompanyEntity {
  + CellPhoneCompanyEntity() 
  + CellPhoneCompanyEntity(String, Set~String~) 
  - Long cellPhoneCompanyId
  - Set~String~ operationalCountries
  - String companyName
  - Set~UserEntity~ users
  + hashCode() int
  + equals(Object) boolean
  # canEqual(Object) boolean
  + toString() String
   Set~String~ operationalCountries
   String companyName
   Set~UserEntity~ users
   Long cellPhoneCompanyId
}
class CellPhoneCompanyRepo {
<<Interface>>
  + getCellPhoneCompaniesByUserId(Long) List~CellPhoneCompanyEntity~
  + getCellPhoneCompanyByCompanyName(String) CellPhoneCompanyEntity
  + getCellPhoneCompanyEntitiesByOperationalCountriesAndCompanyNameContains(String, String) List~CellPhoneCompanyEntity~
  + deleteCellPhoneCompanyFromUserCompaniesTableByCompanyName(String) void
  + findAll() List~CellPhoneCompanyEntity~
  + deleteCellPhoneCompanyFromUserCompaniesTableById(Long) void
  + getCellPhoneCompanyEntitiesByOperationalCountries(String) List~CellPhoneCompanyEntity~
  + deleteCellPhoneCompanyByCompanyName(String) void
  + deleteCellPhoneCompanyByCellPhoneCompanyId(Long) void
  + getCellPhoneCompanyByCellPhoneCompanyId(Long) CellPhoneCompanyEntity
}
class CellPhoneCompanyService {
  + CellPhoneCompanyService(CellPhoneCompanyRepo, UserRepo, CellPhoneCompanyAssembler, CellPhoneCompanyDTOAssembler) 
  + getCellPhoneCompaniesByCountryAndNameContains(String, String) ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~
  + deleteCompanyById(Long) ResponseEntity~?~
  + deleteCompanyByName(String) ResponseEntity~?~
  + updateCompany(CellPhoneCompanyEntity) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + createCompany(CellPhoneCompanyEntity) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + getCellPhoneCompanyDtoInfo(Long) ResponseEntity~EntityModel~CellPhoneCompanyDTO~~
  + getCompanyBySpecificParameter(String, String) ResponseEntity~EntityModel~CellPhoneCompanyEntity~~
  + getCellPhoneCompaniesByUserId(Long) ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~
  + getCellPhoneCompaniesByCountry(String) ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~
   ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyDTO~~~ allCellPhoneCompaniesDtoInfo
   ResponseEntity~CollectionModel~EntityModel~CellPhoneCompanyEntity~~~ allCompanies
}
class CompaniesNotFoundException {
  + CompaniesNotFoundException() 
}
class CompanyExistsException {
  + CompanyExistsException(String) 
}
class CompanyNotFoundException {
  + CompanyNotFoundException(Long) 
  + CompanyNotFoundException(String) 
}
class Config {
  + Config() 
  ~ initDatabase(CellPhoneCompanyRepo, UserRepo) CommandLineRunner
   ObjectMapper objectMapper
}
class GlobalAdvice {
  + GlobalAdvice() 
  ~ userNotFoundHandler(UserNotFoundException) String
  ~ companiesNotFoundHandler(CompaniesNotFoundException) String
  ~ usersNotFoundHandler(UsersNotFoundException) String
  ~ ApiNotReachableHandler(UnknownHostException) String
  ~ UserExistsHandler(UserExistsException) String
  ~ CompanyExistsHandler(CompanyExistsException) String
  ~ UserAPIHandler(APIException) String
  ~ userNotFoundHandler(CompanyNotFoundException) String
  ~ InvalidFormatHandler(InvalidFormatException) String
}
class HairColor {
<<enumeration>>
  + HairColor() 
  + valueOf(String) HairColor
  + values() HairColor[]
}
class Location {
  + Location(String, Street, String) 
  + Location() 
  - Street street
  - String city
  - String country
  + toString() String
  + equals(Object) boolean
  # canEqual(Object) boolean
  + hashCode() int
   String city
   String country
   Street street
}
class Name {
  + Name(String, String, String) 
  + Name() 
  - String title
  - String first
  - String last
  + toString() String
  + equals(Object) boolean
  # canEqual(Object) boolean
  + hashCode() int
   String first
   String last
   String title
}
class Street {
  + Street(String, String) 
  + Street() 
  - String number
  - String name
  + equals(Object) boolean
  # canEqual(Object) boolean
  + hashCode() int
  + toString() String
   String number
   String name
}
class UserController {
  + UserController(UserService) 
  + getUsersWithPathVar(String, String) ResponseEntity~?~
  + deleteUserById(Long) ResponseEntity~?~
  + createUser(UserEntity) ResponseEntity~EntityModel~UserEntity~~
  + getUserByName(String, String) ResponseEntity~?~
  + updateUser(UserEntity) ResponseEntity~EntityModel~UserEntity~~
  + getUserDtoInfo(Long) ResponseEntity~EntityModel~UserDTO~~
  + getUserEntitiesByCompanyId(Long) ResponseEntity~?~
  + getUsersByLocation(String, String, String, String) ResponseEntity~?~
  + linkUserWithCellPhoneCompanies(Long, Set~Long~) ResponseEntity~EntityModel~UserDTO~~
  + deleteUserByEmail(String) ResponseEntity~?~
  + getUsersByAgeAndLastName(Integer, Integer, String) ResponseEntity~?~
   ResponseEntity~CollectionModel~EntityModel~UserEntity~~~ allUsers
   ResponseEntity~CollectionModel~EntityModel~UserDTO~~~ allUsersDtoInfo
}
class UserDTO {
  + UserDTO(UserEntity) 
  - UserEntity user
  + equals(Object) boolean
  + hashCode() int
  + toString() String
   String fullLocation
   String summary
   String email
   Integer age
   UserEntity user
   List~Map~String, String~~ cellPhoneCompanies
   String avatarURL
   String fullName
}
class UserDTOAssembler {
  + UserDTOAssembler() 
  + toModel(UserDTO) EntityModel~UserDTO~
  + toCollectionModel(Iterable~UserDTO~) CollectionModel~EntityModel~UserDTO~~
}
class UserEntity {
  + UserEntity() 
  + UserEntity(String, String, String, Integer, Set~String~, Name, Location, AvatarEntity, Set~CellPhoneCompanyEntity~) 
  - Set~String~ phoneNumbers
  - Long userId
  - String email
  - Name name
  - Integer age
  - String md5
  - AvatarEntity avatarEntity
  - Location location
  - String gender
  ~ Set~CellPhoneCompanyEntity~ cellPhoneCompanies
  + toString() String
  # canEqual(Object) boolean
  + hashCode() int
  + equals(Object) boolean
  - unpackMD5(Map~String, Object~) void
  - unpackAge(Map~String, Object~) void
  - addPhoneToSet(String) void
   Name name
   String gender
   String email
   Integer age
   Set~CellPhoneCompanyEntity~ cellPhoneCompanies
   Set~String~ phoneNumbers
   AvatarEntity avatarEntity
   Long userId
   Location location
   String md5
}
class UserEntityAssembler {
  + UserEntityAssembler() 
  + toModel(UserEntity) EntityModel~UserEntity~
  + toCollectionModel(Iterable~UserEntity~) CollectionModel~EntityModel~UserEntity~~
}
class UserExistsException {
  + UserExistsException(String) 
}
class UserNotFoundException {
  + UserNotFoundException(String) 
  + UserNotFoundException(Long) 
  + UserNotFoundException(String, String) 
}
class UserRepo {
<<Interface>>
  + deleteUserEntityByEmail(String) void
  + getUserEntitiesByLocation(String, String, String, String) List~UserEntity~
  + getUserEntitiesByAge(Integer) List~UserEntity~
  + getUserEntitiesByName(String, String) List~UserEntity~
  + getUserEntityByAgeBetweenAndLastNameStartingWith(Integer, Integer, String) List~UserEntity~
  + getUserEntitiesByFirstName(String) List~UserEntity~
  + getUserEntityByPhoneNumbersContains(String) List~UserEntity~
  + getUserEntityByPhoneNumbers(String) List~UserEntity~
  + getUserEntitiesByCellPhoneCompanyId(Long) List~UserEntity~
  + findAll() List~UserEntity~
  + deleteUserEntityByUserId(Long) void
  + getUserEntityByUserId(Long) List~UserEntity~
  + getUserEntityByEmail(String) List~UserEntity~
  + getUserEntitiesByGender(String) List~UserEntity~
}
class UserService {
  + UserService(UserRepo, UserEntityAssembler, UserDTOAssembler, CellPhoneCompanyRepo) 
  + linkUserWithCellPhoneCompanies(Long, Set~Long~) ResponseEntity~EntityModel~UserDTO~~
  + getUsersByFullName(String, String) ResponseEntity~?~
  + getUsersByLocation(String, String, String, String) ResponseEntity~?~
  + getUserEntitiesByCellPhoneCompanyId(Long) ResponseEntity~?~
  + getUsersByFirstName(String) ResponseEntity~?~
  + updateUser(UserEntity) ResponseEntity~EntityModel~UserEntity~~
  + getUserDtoInfo(Long) ResponseEntity~EntityModel~UserDTO~~
  + createUser(UserEntity) ResponseEntity~EntityModel~UserEntity~~
  - getCorrespondingEntityType(List~UserEntity~) ResponseEntity~RepresentationModel~RepresentationModel~?~~~
  + deleteUserByEmail(String) ResponseEntity~?~
  + deleteUserById(Long) ResponseEntity~?~
  + getUsersBySpecificParameter(String, String) ResponseEntity~?~
  + getUsersByAgeAndName(Integer, Integer, String) ResponseEntity~?~
  - modifyAvatarEntity(AvatarEntity, String) void
   ResponseEntity~CollectionModel~EntityModel~UserEntity~~~ allUsers
   ResponseEntity~CollectionModel~EntityModel~UserDTO~~~ allUsersDtoInfo
}
class UsersNotFoundException {
  + UsersNotFoundException() 
  + UsersNotFoundException(String, String) 
  + UsersNotFoundException(String) 
}
class Utils {
  + Utils() 
  + randomNumberBetweenMinAndMax(int, int) Integer
  + randomHairColorFromEnum() HairColor
}

ApiController  ..>  APIException : «create»
ApiController "1" *--> "apiService 1" ApiService 
ApiService  ..>  APIException : «create»
ApiService  ..>  AvatarEntity : «create»
ApiService "1" *--> "cellPhoneCompanyAssembler 1" CellPhoneCompanyAssembler 
ApiService  ..>  CellPhoneCompanyEntity : «create»
ApiService "1" *--> "cellPhoneCompanyRepo 1" CellPhoneCompanyRepo 
ApiService  ..>  CompanyExistsException : «create»
ApiService "1" *--> "userEntityAssembler 1" UserEntityAssembler 
ApiService  ..>  UserExistsException : «create»
ApiService "1" *--> "userRepo 1" UserRepo 
AvatarEntity "1" *--> "hairColor 1" HairColor 
CellPhoneCompanyController "1" *--> "cellPhoneCompanyService 1" CellPhoneCompanyService 
CellPhoneCompanyDTO "1" *--> "cellPhoneCompany 1" CellPhoneCompanyEntity 
CellPhoneCompanyEntity "1" *--> "users *" UserEntity 
CellPhoneCompanyService "1" *--> "cellPhoneCompanyAssembler 1" CellPhoneCompanyAssembler 
CellPhoneCompanyService "1" *--> "cellPhoneCompanyDTOAssembler 1" CellPhoneCompanyDTOAssembler 
CellPhoneCompanyService "1" *--> "cellPhoneCompanyRepo 1" CellPhoneCompanyRepo 
CellPhoneCompanyService  ..>  CompaniesNotFoundException : «create»
CellPhoneCompanyService  ..>  CompanyExistsException : «create»
CellPhoneCompanyService  ..>  CompanyNotFoundException : «create»
CellPhoneCompanyService  ..>  UserNotFoundException : «create»
CellPhoneCompanyService "1" *--> "userRepo 1" UserRepo 
Config  ..>  AvatarEntity : «create»
Config  ..>  CellPhoneCompanyEntity : «create»
Config  ..>  Location : «create»
Config  ..>  Name : «create»
Config  ..>  Street : «create»
Config  ..>  UserEntity : «create»
Location "1" *--> "street 1" Street 
UserEntity  -->  Location 
UserEntity  -->  Name 
Location  -->  Street 
UserController "1" *--> "userService 1" UserService 
UserDTO "1" *--> "user 1" UserEntity 
UserEntity "1" *--> "avatarEntity 1" AvatarEntity 
UserEntity "1" *--> "cellPhoneCompanies *" CellPhoneCompanyEntity 
UserEntity "1" *--> "location 1" Location 
UserEntity "1" *--> "name 1" Name 
UserService "1" *--> "cellPhoneCompanyRepo 1" CellPhoneCompanyRepo 
UserService  ..>  CompanyNotFoundException : «create»
UserService "1" *--> "userDTOAssembler 1" UserDTOAssembler 
UserService "1" *--> "assembler 1" UserEntityAssembler 
UserService  ..>  UserExistsException : «create»
UserService  ..>  UserNotFoundException : «create»
UserService "1" *--> "userRepo 1" UserRepo 
UserService  ..>  UsersNotFoundException : «create»
